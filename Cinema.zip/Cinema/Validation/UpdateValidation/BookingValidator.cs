﻿namespace CinemaAPI.Validation.UpdateValidation
{
    public class BookingValidator
    {
    }
}
