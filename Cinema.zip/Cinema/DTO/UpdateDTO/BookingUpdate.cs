﻿namespace CinemaAPI.DTO.UpdateDTO
{
    public class BookingUpdate
    {

        public string SeatNumber { get; set; }//المقعد المحجوز بالعرض 
        public DateTime BookingTime { get; set; }

    }
}
