﻿namespace CinemaAPI.DTO.UpdateDTO
{
    public class BookingUpdate
    {

        public int SeatID { get; set; }//المقعد المحجوز بالعرض 
        public DateTime BookingTime { get; set; }

    }
}
