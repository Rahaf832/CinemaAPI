﻿namespace CinemaAPI.DTO.UpdateDTO
{
    public class SeatUpdate
    {
        public string SeatNumber { get; set; }
        public int TheaterID { get; set; }// رقم القاعة الموجود فيها 
    }
}
