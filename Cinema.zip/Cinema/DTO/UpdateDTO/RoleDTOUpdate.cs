﻿namespace CinemaAPI.DTO.UpdateDTO
{
    public class RoleDTOUpdate
    {
        public string Name { get; set; }
    }
}
