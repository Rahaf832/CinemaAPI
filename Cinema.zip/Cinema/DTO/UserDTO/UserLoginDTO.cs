﻿namespace CinemaAPI.DTO.UserDTO
{
    public class UserLoginDTO
    {
        public string Email { get; set; }
        public string PasswordHash { get; set; }
    }
}
