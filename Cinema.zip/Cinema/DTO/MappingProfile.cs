﻿using CinemaAPI.Models;
using AutoMapper;
using CinemaAPI.DTO.CreateDTO;
using CinemaAPI.DTO.ReadDTO;
using CinemaAPI.DTO.UpdateDTO;
using CinemaAPI.DTO;
 
namespace CinemaAPI.DTO
{
    public class MappingProfile:Profile
    {
        public MappingProfile()
        {
            CreateMap<Booking, BookingCreate>().ReverseMap();
            CreateMap<Booking, BookingUpdate>().ReverseMap();
            CreateMap<Booking,BookingRead>().ReverseMap();


        }

    }
}
