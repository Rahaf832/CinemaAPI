﻿namespace CinemaAPI.DTO.ReadDTO
{
    public class SeatRead
    {
        public string SeatNumber { get; set; }
        public int TheaterID { get; set; }// رقم القاعة الموجود فيها 
    }
}
