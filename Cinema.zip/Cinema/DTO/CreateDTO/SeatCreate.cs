﻿namespace CinemaAPI.DTO.CreateDTO
{
    public class SeatCreate
    {
        public string SeatNumber { get; set; }
        public int TheaterID { get; set; }// رقم القاعة الموجود فيها 
    }
}
