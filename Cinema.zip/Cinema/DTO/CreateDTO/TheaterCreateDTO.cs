﻿namespace CinemaAPI.DTO.CreateDTO
{
    public class TheaterCreateDTO
    {
        public string Name { get; set; }
        public int Capacity { get; set; }
    }
}
