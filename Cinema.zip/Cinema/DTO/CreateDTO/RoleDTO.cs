﻿namespace CinemaAPI.DTO.CreateDTO
{
    public class RoleDTO
    {
        public string Name { get; set; }
    }
}
